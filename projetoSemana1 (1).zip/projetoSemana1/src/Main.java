import java.util.Scanner;

class Financiamento {
    //attributes
    double valorImovel;
    int prazoFinanciamento;
    double taxaJurosAnual;

    //constructor
    Financiamento(double valorDesejadoImovel, int prazoFinanciamentoAnos, double taxaJurosAnual) {
        this.valorImovel = valorDesejadoImovel;
        this.prazoFinanciamento = prazoFinanciamentoAnos;
        this.taxaJurosAnual = taxaJurosAnual;
    }

    //methods
    double calcularPagamentoMensal()    {
        return (this.valorImovel / (this.prazoFinanciamento * 12)) * (1 + (this.taxaJurosAnual / 12 / 100));
    }

    double calcularTotalPagamento() {
        return this.calcularPagamentoMensal() * this.prazoFinanciamento * 12;
    }
}

class InterfaceUsuario {
    Scanner sc;

    //constructor
    InterfaceUsuario()  {
        sc = new Scanner(System.in);
    }
    //methods
    double pedirValorImovel()   {
        System.out.println("Digite o valor do imóvel: ");
        return sc.nextDouble();
    }
    int pedirPrazoFinanciamento()   {
        System.out.println("Digite o prazo do financiamento em anos: ");
        return sc.nextInt();
    }
    double pedirTaxaJuros() {
        System.out.println("Digite a taxa de juros anual (em %): ");
        return sc.nextDouble();
    }

    void fecharScanner()    {
        sc.close();
    }
}

public class Main {
    public static void main(String[] args)   {

        InterfaceUsuario interfaceUsuario = new InterfaceUsuario();

        double valorImovel = interfaceUsuario.pedirValorImovel();
        int prazoFinanciamentoAnos = interfaceUsuario.pedirPrazoFinanciamento();
        double taxaJurosAnual = interfaceUsuario.pedirTaxaJuros();

        Financiamento novoFinanciamento = new Financiamento(valorImovel, prazoFinanciamentoAnos, taxaJurosAnual);

        double pagamentoMensal = novoFinanciamento.calcularPagamentoMensal();
        double totalPagamento = novoFinanciamento.calcularTotalPagamento();

        System.out.printf("Pagamento mensal: R$ %.2f\n", pagamentoMensal);
        System.out.printf("Total do pagamento: R$ %.2f\n", totalPagamento);

        interfaceUsuario.fecharScanner();
    }
}
